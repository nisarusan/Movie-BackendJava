package com.movie.moviebackend.models;

import java.io.Serializable;

public class AuthorityKey implements Serializable {
    private String username;
    private String authority;
}