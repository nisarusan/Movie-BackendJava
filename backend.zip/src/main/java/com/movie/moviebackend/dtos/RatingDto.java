package com.movie.moviebackend.dtos;

import com.movie.moviebackend.models.Movie;
import com.movie.moviebackend.models.User;
import jakarta.persistence.*;

public class RatingDto {
    public Long id;
    public User user;
    public UserDto userDto;
    public Long movieId;
    public double rating;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public UserDto getUserDto() {
        return userDto;
    }

    public void setUserDto(UserDto userDto) {
        this.userDto = userDto;
    }

    public Long getMovieId() {
        return movieId;
    }

    public void setMovieId(Long movieId) {
        this.movieId = movieId;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }
}
